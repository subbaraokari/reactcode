import React, { Component } from 'react';
import Post from './Post/Post';
import './Posts.css';
import axios from 'axios';
class Posts extends Component {
    state = {
        posts: [],
        error: false
    }
    render() {
        //console.log(this.state.posts);
        let posts = null;
        if (!this.state.error) {
            posts = this.state.posts.map((post) => {
                //console.log(post.title);
                return <Post key={post.id} post={post} />
            });
        }
        else {
            posts = '<h2>The is a problem in backend</h2>';
        }

        return (
            <div className="posts">
                {posts}
            </div>
        )
    }
    componentDidMount() {
        const promise = axios.get('https://jsonplaceholder.typicode.com/posts');
        promise.then((response) => {
            this.setState({
                posts: response.data
            });
        }).catch((err) => {
            this.setState({
                error: true
            });
        });
    }
}
export default Posts;