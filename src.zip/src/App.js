import React, { Component } from 'react';
import MenuComponent from './components/menu/MenuComponent';
import LoginComponent from './components/login/LoginComponent';
import CompanyList from './components/companies/CompanyList.js';
import WatchList from './components/watchlist/WatchList';
class App extends Component {
  state = {
    email: null,
    password: null,
    isLoggedIn: false,
    companies: [
      { id: 1, name: 'CTS', description: 'sdngdsajidgsa', price: 500 },
      { id: 2, name: 'TCS', description: 'hsadhsgaddsaadhu', price: 400 },
      { id: 3, name: 'Wipro', description: 'sajdhsajdhsahduiasduhsa', price: 400 },
    ],
    watchList: [],
    featureSelected: 'login'
  }
  addToWatchList = (id) => {
    const company = this.state.companies.find(company => company.id === id);
    const watchList = [...this.state.watchList];
    watchList.push(company);
    this.setState({
      watchList: watchList
    });
    console.log(this.state.watchList);
  }
  removeCompanyHandler = (index) => {
    console.log(index);
    let companies = [...this.state.companies];
    companies = companies.splice(index, 1);
    this.setState({
      watchList: companies
    });
    console.log(this.state.watchList);
  }
  logoutHandler = () => {
    this.setState({
      isLoggedIn: false
    });
  }
  loginHandler = (email, password) => {
    if (email === 'ksrao@gmail.com' && password === 'ksrao@123') {
      this.setState({
        isLoggedIn: true
      });
    }
  }
  featureSelectedHandler = (feature) => {
    this.setState({
      featureSelected: feature
    });
  }
  render() {
    let feature = null;
    if (this.state.featureSelected === 'login')
      feature = <LoginComponent submit={this.loginHandler} />
    if (this.state.featureSelected === 'companies')
      feature = <CompanyList add={this.addToWatchList}
        companies={this.state.companies} />
    if (this.state.featureSelected === "watchlist")
      feature = <WatchList remove={this.removeCompanyHandler}
        companies={this.state.watchList} />
    return (
      <div className="container">
        <MenuComponent logout={this.logoutHandler} isLoggedIn={this.state.isLoggedIn}
          click={this.featureSelectedHandler} />
        {feature}
      </div>
    );
  }
}
export default App;