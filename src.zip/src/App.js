import React, { Component } from 'react';
import Recipes from './components/recipes/Recipes';
import Customers from './components/customers/Customers';
import Navbar from './components/navbar/Navbar';
class App extends Component {
  state = {
    featureSelected: 'recipes'
  }
  onFeatureSelected = (feature) => {
    this.setState({
      featureSelected: feature
    });
  }
  render() {
    let feature = null;
    if (this.state.featureSelected === 'recipes') {
      feature = <Recipes />
    }
    else {
      feature = <Customers />
    }
    return (
      <div className="container-fluid">
        <Navbar selectedFeature={this.onFeatureSelected} />
        {feature}
      </div>
    )
  }
}
export default App;