import React, { Component } from 'react';
import Content from './components/content/Content';
import Employees from './components/employees/Employees';
import './App.css';
class App extends Component {
  state = {
    employees: [
      { id: 1, name: 'Suresh', address: 'Chennai' },
      { id: 2, name: 'Ramesh', address: 'Hyderabad' },
      { id: 3, name: 'Vamsi', address: 'Bangalore' },
    ],
    showEmployees: false
  }
  static getDerivedStateFromProps(state, props) {
    console.log('[App.js] getDerivedStateFromProps');
    return state;
  }

  toggleEmployees = () => {
    this.setState({
      showEmployees: !this.state.showEmployees
    });
  }
  deleteEmployeeHandler = (id) => {
    let employees = [...this.state.employees];
    let index = employees.findIndex(emp => {
      return emp.id === id;
    });
    employees.splice(index, 1);
    this.setState({
      employees: employees
    });
  }
  nameChangeHandler = (event, index) => {
    const employees = [...this.state.employees];
    let employee = employees[index];
    employee.name = event.target.value;
    employees[index] = employee;
    this.setState({
      employees: employees
    });
  }
  shouldComponentUpdate(nextProps, nextState) {
    console.log("[App.js] shouldComponentUpdate");
    return true;
  }
  render() {
    console.log('[App.js] render()')
    return (
      <div className="App">
        <Content employees={this.state.employees} click={this.toggleEmployees} />
        <Employees changed={this.nameChangeHandler} delete={this.deleteEmployeeHandler} showEmployees={this.state.showEmployees} employees={this.state.employees} />
      </div>
    )
  }
  componentDidUpdate() {
    console.log("[App.js] Component Did Update");
  }
  componentDidMount() {
    console.log('[App.js] Component Did mount');
  }
}
export default App;