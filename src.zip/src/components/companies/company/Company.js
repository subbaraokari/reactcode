import React from 'react';
const company = props => {
    return (
        <div className="card text-center">
            <h2 className="card-header">
                {props.company.name}
            </h2>
            <div className="card-body">
                {props.company.description}
            </div>
            <h2 className="card-text">{props.company.price}$</h2>
            <button onClick={() => props.addToWatch(props.company.id)} type="button" className="btn btn-danger">Watch</button>
        </div>
    )
}
export default company;