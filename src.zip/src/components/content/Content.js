import React, { Component } from 'react';
import styles from './Content.module.css';
class Content extends Component {

    render() {
        console.log('[Content.js] render()');
        const btnStyle = {
            backgroundColor: "#ff4949",
            color: 'white',
            padding: '1rem',
        }
        const assignedClasses = [];
        if (this.props.employees.length <= 2) {
            assignedClasses.push(styles.Red)
        }
        if (this.props.employees.length <= 1) {
            assignedClasses.push(styles.Bold);
        }
        return (
            <div className={styles.Content}>
                <h2>This is an React App</h2>
                <p className={assignedClasses.join(' ')}>It's Really Working</p>
                <button onClick={this.props.click} style={btnStyle}>Toggle Persons</button>
            </div>
        );
    }
    componentDidMount() {
        console.log('[Content.js] component did mount');
    }
}
export default Content;