import React, { Component } from 'react';
class Customers extends Component {
    render() {
        return (
            <div className="container">
                <h1>This is a customers Component</h1>
            </div>
        );
    }
}
export default Customers;