import React, { Component } from 'react';
import Employee from './employee/Employee';
import styles from './Employees.module.css';
class Employees extends Component {
    componentDidMount() {
        console.log('[Employees.js] componentDidMount');
    }
    render() {
        console.log('[Employees.js] render()');
        let employees = null;
        if (this.props.showEmployees) {
            employees = this.props.employees.map((emp, index) => {
                return <Employee
                    change={($event) => this.props.changed($event, index)}
                    key={emp.id} deleted={() => this.props.delete(emp.id)} employee={emp} />
            });
        }
        return (
            <div className={styles.employees}>
                {employees}
            </div>
        );
    }
    shouldComponentUpdate() {
        console.log('[Employees.js] component shouldupdate');
        return true;
    }
    componentDidUpdate() {
        console.log('[Employees.js] component did update');
    }
}
export default Employees;