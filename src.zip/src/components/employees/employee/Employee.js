import React, { Component } from 'react';
import styles from './Employee.module.css';
class Employee extends Component {
    componentDidMount() {
        console.log("[Employee.js] component did mount");
    }
    render() {
        console.log("[Employee.js] render()");
        return (
            <div className={styles.employee}>
                <p onClick={this.props.deleted}>The employee name is {this.props.employee.name} and address is {this.props.employee.address}</p>
                <input type="text" value={this.props.employee.name} onChange={this.props.change} />
            </div>);
    }
}
export default Employee;