import React, { Component } from 'react'
class LoginComponent extends Component {
    state = {
        email: '',
        password: '',
        isEmailValid: true,
        isPasswordValid: true
    }
    emailInputChangeHandler = (event) => {
        this.setState({
            email: event.target.value
        });
    }
    passwordInputChangeHandler = (event) => {
        this.setState({
            password: event.target.value
        });
    }
    formSubmissionHandler = event => {
        event.preventDefault();
        if (this.state.email.trim() === '') {
            this.setState({
                isEmailValid: false
            });
            return;
        }
        if (this.state.password.trim() === '') {
            this.setState({
                isPasswordValid: false
            });
            return;
        }

        this.props.submit(this.state.email, this.state.password);
        this.state.email = '';
        this.state.password = '';
    }
    render() {
        return (
            <form onSubmit={this.formSubmissionHandler}>
                <div className="form-group">
                    <label htmlFor="email">Email</label>
                    <input type="text"
                        className="form-control"
                        name="email"
                        value={this.state.email}
                        onChange={this.emailInputChangeHandler}
                        id="email"
                    ></input>
                    {!this.state.isEmailValid ? <p className="text-danger">Please enter email</p> : null}
                </div>
                <div className="form-group">
                    <label htmlFor="password">Password</label>
                    <input type="password"
                        className="form-control"
                        name="password"
                        value={this.state.password}
                        onChange={this.passwordInputChangeHandler}
                        id="password"></input>
                    {!this.state.isPasswordValid ? <p className="text-danger">Please enter password</p> : null}
                </div>
                <button type="submit" id="submit" className="btn btn-primary">Submit</button>
            </form>
        )
    }
}
export default LoginComponent;