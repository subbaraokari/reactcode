import React from 'react';
const navbar = (props) => {
    return (
        <nav className="navbar navbar-expand-md navbar-dark bg-primary">
            <a className="navbar-brand">Recipe App</a>
            <button className="navbar-toggler" data-toggle="collapse"
                data-target="#navcontent">
                <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navcontent">
                <ul className="navbar-nav">
                    <li className="nav-item"><a onClick={() => props.selectedFeature('recipes')} href="#" className="nav-link">Recipes</a></li>
                    <li className="nav-item"><a onClick={() => props.selectedFeature('customers')} href="#" className="nav-link">Customers</a></li>
                </ul>
            </div>
        </nav>
    );
}
export default navbar;