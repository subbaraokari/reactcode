import React, { Component } from 'react';
import RecipeList from './recipe-list/RecipeList';
import RecipeDetail from './recipe-detail/RecipeDetail';
class Recipes extends Component {
    state = {
        recipes: [
            { id: 1, name: 'Paneer Butter Masala', description: 'Paneer Butter Masala is one of India’s most popular paneer gravy recipe. This recipe with Indian cottage cheese cubes in a creamy tomato sauce is one that I have been making for a long time. With my video and step-by-step guide you can easily make this restaurant style paneer butter masala at home!', imageUrl: 'https://www.vegrecipesofindia.com/wp-content/uploads/2020/01/paneer-butter-masala-1-1152x1536.jpg' },
            { id: 2, name: 'Matar Paneer', description: 'Matar paneer recipe – a popular Indian Curry dish made with green peas and Indian cottage cheese, is from the versatile Northern Indian cuisine that has many different (and delicious) variations. I’m sharing our family recipe of a flavorful and simple home-style mutter paneer.', imageUrl: 'https://www.vegrecipesofindia.com/wp-content/uploads/2021/02/matar-paneer-0-1024x1536.jpg' },
            { id: 3, name: 'Paneer Tikka', description: 'Paneer Tikka is a popular and delicious tandoori snack where paneer (Indian cottage cheese cubes) are marinated in a spiced yogurt-based marinade, arranged on skewers and grilled in the oven.', imageUrl: 'https://www.vegrecipesofindia.com/wp-content/uploads/2011/10/grilled-paneer-tikka.jpg' }
        ],
        selectedRecipe: null
    }
    recipeSelected = (id) => {
        const recipes = [...this.state.recipes];
        const recipe = recipes.find(recipe => {
            return recipe.id === id;
        });
        this.setState({
            selectedRecipe: recipe
        });
    }
    render() {
        let recipeDetail = <p>Please Select Recipe</p>;
        if (this.state.selectedRecipe) {
            recipeDetail = <RecipeDetail recipe={this.state.selectedRecipe} />
        }
        return (
            <div className="row">
                <div className="col-md-8">
                    <RecipeList click={this.recipeSelected} recipes={this.state.recipes} />
                </div>
                <div className="col-md-4">
                    {recipeDetail}
                </div>
            </div>
        )
    }
}
export default Recipes;