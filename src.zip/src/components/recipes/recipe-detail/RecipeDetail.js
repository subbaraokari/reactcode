import React from 'react';
import recipe from '../recipe-list/recipe/Recipe';
const recipeDetail = (props) => {
    return (
        <div className="col-sm-12 mt-5" >
            <div className="card">
                <img style={{ height: "200px" }} className="card-img-top" src={props.recipe.imageUrl} />
                <div className="card-body">
                    <h2 className="card-title">{props.recipe.name}</h2>
                    <p className="text-muted">{props.recipe.description}</p>
                    <button className="btn btn-primary">Add To Cart</button>
                </div>
            </div>
        </div>
    )
}
export default recipeDetail;