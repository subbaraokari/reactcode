import React, { Component } from 'react';
import Recipe from './recipe/Recipe';
class RecipeList extends Component {
    render() {
        let recipes = this.props.recipes.map(recipe => {
            return <Recipe key={recipe.id} clicked={() => this.props.click(recipe.id)} recipe={recipe} />
        });
        return (
            <div className="row">
                <div className="col-sm-12">
                    {recipes}
                </div>
            </div>
        )
    }
}
export default RecipeList;