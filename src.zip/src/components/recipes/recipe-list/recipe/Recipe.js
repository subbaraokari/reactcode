import React from 'react';
const recipe = props => {
    return (
        <div onClick={props.clicked} className="list-group-item d-flex justify-content-between" >
            <div>
                <h3>{props.recipe.name}</h3>
                <p>{props.recipe.description}</p>
            </div>
            <div>
                <img style={{ width: "300px", height: "200px" }} src={props.recipe.imageUrl} alt={props.recipe.name}></img>
            </div>
        </div>
    )
}
export default recipe;