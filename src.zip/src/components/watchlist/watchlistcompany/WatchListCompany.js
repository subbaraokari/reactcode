import React from 'react';
const watchListCompany = props => {
    return (
        <div className="card">
            <h2 className="card-header">
                {props.company.name}
            </h2>
            <p className="card-body">
                {props.company.description}
            </p>
            <h3 className="card-title">{props.company.price}</h3>
            <button type="button" onClick={props.removeCompany} className="btn btn-danger">Remove</button>
        </div>
    )
}
export default watchListCompany;